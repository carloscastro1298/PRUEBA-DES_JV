export default function ReservationCard(reservation) {
  const { workspace, date, startHour, endHour, reason, status } = reservation;

  // Paleta de colores sutiles y profesionales para los estados de la reserva
  const statusStyles = {
    'Pendiente': 'bg-amber-50 text-amber-700 border-amber-200',
    'Aprobada':  'bg-emerald-50 text-emerald-700 border-emerald-200',
    'Rechazada': 'bg-slate-100 text-slate-600 border-slate-200',
    'Cancelada': 'bg-rose-50 text-rose-700 border-rose-200'
  };

  // Asigna el estilo correspondiente o un gris neutro por defecto
  const badgeClass = statusStyles[status] || 'bg-slate-50 text-slate-700 border-slate-200';

  return `
    <article
      class="p-5 bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md hover:border-slate-300 transition-all duration-200 antialiased"
    >
      <!-- Cabecera de la Tarjeta -->
      <div class="flex items-center justify-between gap-4 mb-3 flex-wrap">
        <h3 class="font-semibold text-slate-900 text-base tracking-tight">
          ${workspace}
        </h3>
        <span class="text-xs font-medium px-2.5 py-0.5 rounded-full border ${badgeClass}">
          ${status}
        </span>
      </div>

      <!-- Cuerpo de Información Principal -->
      <div class="space-y-1.5 border-t border-slate-100 pt-3">
        
        <div class="flex items-center gap-4 text-xs text-slate-500 font-medium flex-wrap">
          <p class="flex items-center gap-1">
            <span class="opacity-70">📅</span> ${date}
          </p>
          <p class="flex items-center gap-1">
            <span class="opacity-70">⏰</span> ${startHour} - ${endHour}
          </p>
        </div>

        <p class="text-sm text-slate-600 font-normal pt-1 italic">
          "${reason}"
        </p>

      </div>
    </article>
  `;
}

