import { removeSession } from "@/utils";
import { navigateTo } from "@/router/router";

export default function Sidebar() {
  setTimeout(() => {
    document
      .querySelector("#logoutBtn")
      ?.addEventListener("click", () => {
        // Ejecutamos tu utilidad para limpiar el localStorage/sessionStorage antes de salir
        removeSession(); 
        navigateTo("/");
      });
  });

  return `
    <aside
      class="w-64 bg-slate-950 text-slate-200 h-screen p-5 flex flex-col justify-between border-r border-slate-900 antialiased"
    >
      <div>
        <!-- Logo corporativo minimalista -->
        <div class="flex items-center gap-3 mb-8 px-2">
          <div class="w-2.5 h-6 bg-indigo-500 rounded-full"></div>
          <span class="font-bold text-base tracking-wider text-white uppercase">
            Sistema de Reservas
          </span>
        </div>

        <!-- Menú de navegación principal -->
        <nav class="flex flex-col gap-1.5">
          
          <a 
            href="/home" 
            class="flex items-center gap-3 px-4 py-3 bg-slate-900 text-white rounded-xl text-sm font-medium border border-slate-800 shadow-sm transition-all duration-200" 
            data-link
          >
            <span>Panel de Control</span>
          </a>

        </nav>
      </div>

      <!-- Pie del Sidebar: Botón de Cerrar Sesión Estilizado -->
      <div class="border-t border-slate-900 pt-4 px-1">
        <button
          id="logoutBtn"
          class="w-full flex items-center justify-between px-4 py-3 cursor-pointer text-sm font-medium text-rose-400 bg-transparent hover:bg-rose-950/30 hover:text-rose-300 rounded-xl transition-all duration-200"
        >
          <span>Cerrar sesión</span>
          <span class="text-xs opacity-60">→</span>
        </button>
      </div>

    </aside>
  `;
}

