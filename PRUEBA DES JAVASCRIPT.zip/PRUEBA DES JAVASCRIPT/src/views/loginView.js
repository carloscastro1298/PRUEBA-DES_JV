import { loginController } from "@/controllers/login.controller";

export default function loginView() {
  setTimeout(() => {
    loginController();
  });

  return `
    <div class="min-h-screen flex justify-center items-center bg-slate-50 px-4 antialiased">

      <div class="bg-white p-8 rounded-2xl border border-slate-200 shadow-xl shadow-slate-100/50 w-full max-w-sm">

        <!-- Encabezado institucional minimalista -->
        <div class="text-center mb-6">
          <div class="w-2 h-8 bg-indigo-600 rounded-full mx-auto mb-3"></div>
          <h1 class="text-2xl font-bold text-slate-900 tracking-tight">
            Bienvenido al Sistema de Reservas
          </h1>
          <p class="text-xs text-slate-500 mt-1">
          </p>
        </div>

        <form id="loginForm" class="space-y-4">

          <!-- Campo de Correo -->
          <div>
            <label class="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
              Correo electrónico
            </label>
            <input
              type="email"
              name="email"
              placeholder="nombre@empresa.com"
              required
              class="w-full border border-slate-200 px-3 py-2.5 rounded-xl text-sm bg-slate-50/50 transition-all focus:outline-none focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 placeholder:text-slate-400"
            >
          </div>

          <!-- Campo de Contraseña -->
          <div>
            <label class="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
              Contraseña
            </label>
            <input
              type="password"
              name="password"
              placeholder="••••••••"
              required
              class="w-full border border-slate-200 px-3 py-2.5 rounded-xl text-sm bg-slate-50/50 transition-all focus:outline-none focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 placeholder:text-slate-400"
            >
          </div>

          <!-- Botón de Acción -->
          <button
            type="submit"
            class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2.5 rounded-xl text-sm shadow-sm shadow-indigo-100 transition-all duration-200 mt-2"
          >
            Ingresar
          </button>

        </form>

      </div>

    </div>
  `;
}
