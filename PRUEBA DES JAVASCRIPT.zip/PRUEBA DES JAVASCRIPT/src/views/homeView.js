import Sidebar from "@/components/Sidebar";
import { getSession } from "@/utils";
import { homeController } from "@/controllers/home.controller";

export default function homeView() {
  const user = getSession();

  setTimeout(() => {
    homeController();
  });

  const roleBadgeStyle = user?.role === "admin" 
    ? "bg-indigo-50 text-indigo-700 border-indigo-200" 
    : "bg-emerald-50 text-emerald-700 border-emerald-200";

  return `
    <div class="flex antialiased bg-slate-50 min-h-screen">

      ${Sidebar()}

      <main class="flex-1 p-8 overflow-y-auto">

        <div class="flex items-center justify-between border-b border-slate-200 pb-5 mb-6 gap-4 flex-wrap">
          <div>
            <h1 class="text-xl font-bold text-slate-900 tracking-tight">
              Bienvenido! ${user?.name}
            </h1>
            <p class="text-xs text-slate-500 mt-0.5">
              Portal de control y asignación de horarios
            </p>
          </div>
          
          <span class="text-xs font-semibold px-3 py-1 rounded-full border uppercase tracking-wider ${roleBadgeStyle}">
            Rol: ${user?.role}
          </span>
        </div>

        ${
          user?.role === "admin"
            ? `
              <section
                class="bg-gradient-to-r from-slate-900 to-indigo-950 p-6 rounded-2xl border border-slate-800 shadow-lg mb-6 text-slate-200 relative overflow-hidden"
              >
                <div class="absolute right-0 bottom-0 opacity-10 translate-x-4 translate-y-4 font-bold text-7xl select-none">ADMIN</div>
                
                <h2 class="font-bold text-lg text-white mb-1.5 tracking-tight">
                  Panel Administrador
                </h2>

                <p class="text-sm text-slate-400 max-w-xl">
                  Aqui puedes: auditar, autorizar, rechazar o eliminar cualquier reserva registrada en el sistema.
                </p>

                <a
                  href="/gestion-espacios"
                  data-link
                  class="inline-block mt-4 bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs px-4 py-2 rounded-xl shadow-sm shadow-indigo-950 transition-all duration-200 text-center cursor-pointer"
                >
                  Gestion de Espacios
                </a>

              </section>
            `
            : `
              <section
                class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm mb-6"
              >
                <h2 class="font-bold text-lg text-slate-900 mb-1.5 tracking-tight">
                  Panel de Usuario
                </h2>

                <p class="text-sm text-slate-500 max-w-xl">
                  Aqui puuedes: visualizar el estado de tus solicitudes personales. Recuerda que solo puedes modificar las reservas si aún se encuentran en estado pendiente.
                </p>

                <a
                  href="/nueva-reserva"
                  data-link
                  class="inline-block mt-4 bg-emerald-600 hover:bg-emerald-700 text-white font-medium text-xs px-4 py-2 rounded-xl shadow-sm shadow-emerald-100 transition-all duration-200 text-center cursor-pointer"
                >
                  Agendar nueva reserva
                </a>

              </section>
            `
        }

        <section
          class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm"
        >

          <div
            class="flex justify-between items-center border-b border-slate-100 pb-4 mb-5 flex-wrap gap-2"
          >
            <h2 class="font-bold text-lg text-slate-900 tracking-tight">
              Historial de Reservas
            </h2>

            <span
              class="text-xs font-medium text-slate-400 bg-slate-50 border border-slate-200/60 px-2.5 py-0.5 rounded-full"
            >
              ${
                user?.role === "admin"
                  ? "Vista global del sistema"
                  : "Filtrado por tu identificador"
              }
            </span>
          </div>

          <div
            id="reservationsContainer"
            class="grid gap-4 sm:grid-cols-1 md:grid-cols-2"
          >
            <div class="w-full text-center py-12 col-span-2">
              <div class="inline-block w-6 h-6 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin mb-2"></div>
              <p class="text-sm text-slate-500 font-medium animate-pulse">
                Consultando registros en el servidor...
              </p>
            </div>
          </div>

        </section>

      </main>

    </div>
  `;
}

