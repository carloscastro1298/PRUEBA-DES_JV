import ReservationCard from "@components/ReservationCard";
import { getReservations, updateReservation, deleteReservation } from "@services/reservation.service";
import { getSession } from "@/utils";

export const homeController = async () => {
  const container = document.querySelector("#reservationsContainer");
  const user = getSession();

  if (!container || !user) return;

  const renderList = async () => {
    try {
      const reservations = await getReservations();

      const filteredReservations =
        user.role === "admin"
          ? reservations
          : reservations.filter((reservation) => reservation.userId === user.id);

      container.innerHTML = filteredReservations?.length
        ? filteredReservations
            .map((reservation) => `
              <div class="flex flex-col gap-2 bg-white p-2 rounded-2xl border border-slate-100 shadow-sm">
                ${ReservationCard(reservation)}
                <div class="flex gap-2 justify-end px-3 pb-2 pt-1">
                  ${renderActionButtons(reservation, user)}
                </div>
              </div>
            `)
            .join("")
        : `
          <div class="w-full text-center py-8 col-span-2">
            <p class="text-slate-500 text-sm">No hay reservas disponibles</p>
          </div>
        `;
    } catch (error) {
      container.innerHTML = `
        <div class="w-full text-center py-8 col-span-2">
          <p class="text-rose-500 text-sm">Error al cargar datos</p>
        </div>
      `;
    }
  };

  const renderActionButtons = (res, currentUser) => {
    if (currentUser.role === "admin") {
      return `
        <button class="btn-approve bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium px-3 py-1.5 rounded-lg transition-all cursor-pointer" data-id="${res.id}">Aprobar</button>
        <button class="btn-reject bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-medium px-3 py-1.5 rounded-lg transition-all cursor-pointer" data-id="${res.id}">Rechazar</button>
        <button class="btn-delete bg-white border border-slate-200 hover:bg-rose-50 text-rose-600 text-xs font-medium px-3 py-1.5 rounded-lg transition-all cursor-pointer" data-id="${res.id}">Eliminar</button>
      `;
    }

    let buttons = "";

    if (res.status === "Pendiente") {
      buttons += `<button class="btn-edit bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-medium px-3 py-1.5 rounded-lg transition-all cursor-pointer" data-id="${res.id}">Modificar</button>`;
    }

    if (res.status === "Pendiente" || res.status === "Aprobada") {
      buttons += `<button class="btn-cancel bg-white border border-slate-200 hover:bg-rose-50 text-rose-600 text-xs font-medium px-3 py-1.5 rounded-lg transition-all cursor-pointer" data-id="${res.id}">Cancelar</button>`;
    }

    return buttons;
  };

  container.addEventListener("click", async (e) => {
    const target = e.target;
    const id = target.dataset.id;
    if (!id) return;

    try {
      if (target.classList.contains("btn-approve")) {
        await updateReservation(id, { status: "Aprobada" });
        await renderList();
      } 
      else if (target.classList.contains("btn-reject")) {
        await updateReservation(id, { status: "Rechazada" });
        await renderList();
      } 
      else if (target.classList.contains("btn-delete")) {
        if (confirm("¿Deseas eliminar permanentemente esta reserva?")) {
          await deleteReservation(id);
          await renderList();
        }
      } 
      else if (target.classList.contains("btn-cancel")) {
        await updateReservation(id, { status: "Cancelada" });
        await renderList();
      } 
      else if (target.classList.contains("btn-edit")) {
        const reservations = await getReservations();
        const currentRes = reservations.find(r => r.id == id);
        const newReason = prompt("Ingresa el nuevo motivo de tu reserva:", currentRes?.reason || "");
        
        if (newReason !== null && newReason.trim() !== "") {
          await updateReservation(id, { reason: newReason });
          await renderList();
        }
      }
    } catch (error) {
      alert("Error: " + error.message);
    }
  });

  await renderList();
};

