import { saveSession } from "@/utils";
import { navigateTo } from "@/router/router";
import { http } from "@/api/http";

export const loginController = () => {
  const form = document.querySelector("#loginForm");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const email = form.email.value.trim();
    const password = form.password.value.trim();

    try {
      const users = await http.get(
        `/users?email=${email}&password=${password}`,
      );

      if (!users.length) {
        alert("Credenciales incorrectas");
        return;
      }

      saveSession({
        id: users[0].id,
        name: users[0].name,
        role: users[0].role,
      });

      navigateTo("/home");
    } catch (error) {
      console.error(error);
      alert("Error conectando con la API");
    }
  });
};
export class LoginController {
    static async login(email, password) {
        try {
            const response = await fetch(`http://localhost:3000/users?email=${email}&password=${password}`);
            const users = await response.json();

            if (users.length === 0) {
                throw new Error('Credenciales incorrectas.');
            }

            // Guardar sesión de forma persistente
            localStorage.setItem('currentUser', JSON.stringify(users[0]));
            
            // Redirección dinámica SPA usando hash
            window.location.hash = '#/home';
        } catch (error) {
            alert(error.message);
        }
    }

    static logout() {
        localStorage.removeItem('currentUser');
        window.location.hash = '#/login';
    }
}
